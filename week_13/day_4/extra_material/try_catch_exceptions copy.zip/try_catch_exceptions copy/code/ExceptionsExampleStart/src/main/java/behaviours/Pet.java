package behaviours;

public interface Pet {
    public String getName();
}
