package exceptions;

public class NullStringException extends Exception{
    public NullStringException(String message){
        super(message);
    }


}
